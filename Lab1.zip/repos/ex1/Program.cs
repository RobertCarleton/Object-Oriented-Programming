﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Q1

            Console.WriteLine("Please Enter a Percentage Grade:");
            int percentage = int.Parse(Console.ReadLine());

            if (percentage >= 90 && percentage <= 100)
                Console.WriteLine("H1, you got 100 points!");
            if (percentage >= 80 && percentage < 90)
                Console.WriteLine("H2, you got 88 points!");
            if (percentage >= 70 && percentage < 80)
                Console.WriteLine("H3, you got 77 points!");
            if (percentage >= 60 && percentage < 70)
                Console.WriteLine("H4, you got 66 points!");
            if (percentage >= 50 && percentage < 60)
                Console.WriteLine("H5, you got 56 points!");
            if (percentage >= 40 && percentage < 50)
                Console.WriteLine("H6, you got 46 points!");
            if (percentage >= 30 && percentage < 40)
                Console.WriteLine("H7, you got 37 points!");
            if (percentage >= 0 && percentage < 30)
                Console.WriteLine("H8, you got 0 points!");
            if (percentage < 0 || percentage > 100)
                Console.WriteLine("There is an error with the percentage you entered!");
        }
    }
}
