﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Q4

            int totalPoints = 0, lowestPoints = 100;

            Console.WriteLine("Enter each of your 7 exam results as percentage:");
            for (int i = 0; i < 7; i++)
            {
                Console.WriteLine($"Enter result {i + 1} ");
                int result = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Higher or Ordinay? (Indicate with H / O)");
                string level = Console.ReadLine();

                //get points for this percentage
                if (level == "H")
                {

                    if (result >= 90 && result <= 100)
                        totalPoints += 100;
                    if (result >= 80 && result < 90)
                        totalPoints += 88;
                    if (result >= 70 && result < 80)
                        totalPoints += 77;
                    if (result >= 60 && result < 70)
                        totalPoints += 66;
                    if (result >= 50 && result < 60)
                        totalPoints += 56;
                    if (result >= 40 && result < 50)
                        totalPoints += 46;
                    if (result >= 30 && result < 40)
                        totalPoints += 37;

                }

                else if (level == "O")
                {

                    if (result >= 90 && result <= 100)
                        totalPoints += 56;
                    if (result >= 80 && result < 90)
                        totalPoints += 46;
                    if (result >= 70 && result < 80)
                        totalPoints += 37;
                    if (result >= 60 && result < 70)
                        totalPoints += 28;
                    if (result >= 50 && result < 60)
                        totalPoints += 20;
                    if (result >= 40 && result < 50)
                        totalPoints += 12;
                }

                if (result < lowestPoints) 
                    lowestPoints = result;

            }

            Console.WriteLine($"Your total points are {totalPoints - lowestPoints}!");



        }
    }
}
