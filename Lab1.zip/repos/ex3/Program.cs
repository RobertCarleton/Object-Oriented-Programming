﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Q3

            Console.WriteLine("Higher or Ordinay? (Indicate with H / O)");
            string level = Console.ReadLine();

            if (level == "H")
            {
                Console.WriteLine("Give your percentage grade for higher level:");
                int higherpoints = int.Parse(Console.ReadLine());

                if (higherpoints >= 90 && higherpoints <= 100)
                    Console.WriteLine("You got a H1, that's 100 points!");
                if (higherpoints >= 80 && higherpoints < 90)
                    Console.WriteLine("You got a H2, that's 88 points!");
                if (higherpoints >= 70 && higherpoints < 80)
                    Console.WriteLine("You got a H3, that's 77 points!");
                if (higherpoints >= 60 && higherpoints < 70)
                    Console.WriteLine("You got a H4, that's 66 points!");
                if (higherpoints >= 50 && higherpoints < 60)
                    Console.WriteLine("You got a H5, that's 56 points!");
                if (higherpoints >= 40 && higherpoints < 50)
                    Console.WriteLine("You got a H6, that's 46 points!");
                if (higherpoints >= 30 && higherpoints < 40)
                    Console.WriteLine("You got a H7, that's 37 points!");
                if (higherpoints >= 0 && higherpoints < 30)
                    Console.WriteLine("You got a H8, that's 0 points!");
                if (higherpoints < 0 || higherpoints > 100)
                    Console.WriteLine("Error with your input");
            }
            else if (level == "O")
            {
                Console.WriteLine("Give your percentage grade for ordinary level:");
                int lowerpoints = int.Parse(Console.ReadLine());

                if (lowerpoints >= 90 && lowerpoints <= 100)
                    Console.WriteLine("You got a O1, that's 56 points!");
                if (lowerpoints >= 80 && lowerpoints < 90)
                    Console.WriteLine("You got a O2, that's 46 points!");
                if (lowerpoints >= 70 && lowerpoints < 80)
                    Console.WriteLine("You got a O3, that's 37 points!");
                if (lowerpoints >= 60 && lowerpoints < 70)
                    Console.WriteLine("You got a O4, that's 28 points!");
                if (lowerpoints >= 50 && lowerpoints < 60)
                    Console.WriteLine("You got a O5, that's 20 points!");
                if (lowerpoints >= 40 && lowerpoints < 50)
                    Console.WriteLine("You got a O6, that's 12 points!");
                if (lowerpoints >= 0 && lowerpoints < 40)
                    Console.WriteLine("You got a O7/O8, that's 0 points!");
                if (lowerpoints < 0 || lowerpoints > 100)
                    Console.WriteLine("Error with your input");
            }
            else
                Console.WriteLine("Error with your input");
        }
    }
}
