﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Q2

            Console.WriteLine("Please Enter a Grade (H1, H2, etc):");
            string input = Console.ReadLine();
            int points = 0;
            switch (input) 
            {
                case "H1":
                    points = 100; break;
                case "H2":
                    points = 88; break;
                case "H3":
                    points = 77; break;
                case "H4":
                    points = 66; break;
                case "H5":
                    points = 56; break;
                case "H6":
                    points = 46; break;
                case "H7":
                    points = 37; break;
                case "default":
                    points = 0; break;
            }
            Console.WriteLine($"Your entered grade {input} has a points value of {points}");
        }
    }
}
